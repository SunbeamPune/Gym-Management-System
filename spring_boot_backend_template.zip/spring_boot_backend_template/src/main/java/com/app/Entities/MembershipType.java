package com.app.Entities;

public enum MembershipType {
	
REGULAR,MONTHLY,YEARLY,QUATERLY,SEMI_YEARLY;

}
